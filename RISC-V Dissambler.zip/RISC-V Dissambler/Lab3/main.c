#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

int binaryToDecimalUnsigned( char *binString, int size) {
   char a[size];
   for(int i = 0; i < size; i++){
      a[i] = binString[i];
   }

   
   int val = 0;
   for(int i = 0 ; i < size ;i++){
      if(a[i] == '1'){
         val = val + pow(2,  size - 1 - i);   
      }
   }
   return val;   

} 

int binaryToDecimalSigned(char * binString, int size){
   char a[size];
   
   for(int i = 0; i < size; i++){
      a[i] = binString[i];
   }
   //a[size] ='\0';
   int sign = 1;
   int val = 0;
   
   if(a[0] == '1'){
     
      for(int i = 0; i < size; i++){
         if(a[i] == '1'){
             a[i] = '0';
         }
         if(a[i] == '0'){
            a[i] = '1';
         }
      }

   return (-1) * (binaryToDecimalUnsigned(a, size) + 1);
   }
    else if(a[0] =='0'){
   
      val = binaryToDecimalUnsigned(a, size);
      return val;
   }

}

void RType(char * binStr){
   char funct3[4];
   char funct7[8];
   int regDes;
   int regSrc1;
   int regSrc2;
   char rd[6];
   char rs1[6];
   char rs2[6];
   for(int i = 0; i < 5;i++ ){
      rs2[i] = binStr[7+i];
   }
   rs2[5]='\0';
   regSrc2 = binaryToDecimalUnsigned(rs2, 5);
   for(int i = 0; i < 5;i++ ){
      rs1[i] = binStr[12+i];
   }
   rs1[5]='\0';
   regSrc1 = binaryToDecimalUnsigned(rs1, 5);   
   for(int i = 0; i < 5;i++ ){
      rd[i] = binStr[20+i];
   }
   rd[5] ='\0';
   regDes = binaryToDecimalUnsigned(rd, 5);
   for(int i = 0;i < 7;i++){
      funct7[i] = binStr[i];
   }
   funct7[7]='\0';

   for(int i = 0; i < 3;i++){
      funct3[i] = binStr[17 + i];
   }
   funct3[3]='\0';
   if(strcmp(funct3, "000")==0 && strcmp(funct7, "0000000")==0){
      printf("add x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }
   if(strcmp(funct3, "000")==0 && strcmp(funct7, "0100000")==0){
      printf("sub x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }
   if(strcmp(funct3, "101")==0 && strcmp(funct7, "0000000")==0){
      printf("srl x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }      
   if(strcmp(funct3, "101")==0 && strcmp(funct7, "0100000")==0){
      printf("sra x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }   
   if(strcmp(funct3, "100")==0){
      printf("xor x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }   
   if(strcmp(funct3, "110")==0){
      printf("or x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }   
   if(strcmp(funct3, "111")==0){
      printf("and x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }   
   if(strcmp(funct3, "001")==0){
      printf("sll x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }   
   if(strcmp(funct3, "010")==0){
      printf("slt x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }  
   if(strcmp(funct3, "011")==0){
      printf("sltu x%d, x%d, x%d\n", regDes, regSrc1,regSrc2);
   }    
}

void SType(char * binStr){
   char funct3[4];
   //char funct7[8];
  // int regDes;
   char imm[13];
   int regSrc1;
   int regSrc2;
   //char rd[6];
   char rs1[6];
   char rs2[6];
   char immVal;
   for(int i = 0; i < 5;i++ ){
      rs2[i] = binStr[7+i];
   }
   rs2[5]='\0';
   regSrc2 = binaryToDecimalUnsigned(rs2, 5);
   for(int i = 0; i < 5;i++ ){
      rs1[i] = binStr[12+i];
   }
   rs1[5]='\0';
   regSrc1 = binaryToDecimalUnsigned(rs1, 5);   
   /*
   for(int i = 0; i < 5;i++ ){
      rd[i] = binStr[20+i];
   }
   rd[5] ='\0';
   regDes = binaryToDecimalUnsigned(rd, 5);
   */
  
   /*for(int i = 0;i < 7;i++){
      funct7[i] = binStr[i];
   }
   funct7[7]='\0';
  */
   for(int i = 0; i < 3;i++){
      funct3[i] = binStr[17 + i];
   }
   funct3[3]='\0';

   for(int i = 0; i < 5; i++){
      imm[7 + i] = binStr[20 + i];
   }
   for(int i =0; i < 7;i++){
      imm[i] = binStr[i]; 
   }
   imm[12] = '\0';
   immVal = binaryToDecimalSigned(imm, 12);
   if(strcmp(funct3, "000")==0){
      printf("sb x%d, %d(x%d)\n", regSrc2, immVal,  regSrc1);
   }
   else if(strcmp(funct3, "001")==0){
      printf("sh x%d, %d(x%d)\n", regSrc2, immVal,  regSrc1);
   }   
   else if(strcmp(funct3, "010")==0){
      printf("sw x%d, %d(x%d)\n", regSrc2, immVal,  regSrc1);
   }
   else if(strcmp(funct3, "011")==0){
      printf("sd x%d, %d(x%d)\n", regSrc2, immVal,  regSrc1);
   }
}
/*Btype below*/
void BType(char * binStr){
   char funct3[4];
   //char funct7[8];
  // int regDes;
   char imm[13];
   int regSrc1;
   int regSrc2;
   //char rd[6];
   char rs1[6];
   char rs2[6];
   char immVal;
   for(int i = 0; i < 5;i++ ){
      rs2[i] = binStr[7+i];
   }
   rs2[5]='\0';
   regSrc2 = binaryToDecimalUnsigned(rs2, 5);
   for(int i = 0; i < 5;i++ ){
      rs1[i] = binStr[12+i];
   }
   rs1[5]='\0';
   regSrc1 = binaryToDecimalUnsigned(rs1, 5);   
   /*
   for(int i = 0; i < 5;i++ ){
      rd[i] = binStr[20+i];
   }
   rd[5] ='\0';
   regDes = binaryToDecimalUnsigned(rd, 5);
   */
  
   /*for(int i = 0;i < 7;i++){
      funct7[i] = binStr[i];
   }
   funct7[7]='\0';
  */
   for(int i = 0; i < 3;i++){
      funct3[i] = binStr[17 + i];
   }
   funct3[3]='\0';
   imm[0] = binStr[0];
   imm[1] = binStr[24];
   for(int i = 0; i < 6; i++){
      imm[2+i] = binStr[i];
   }
   for(int i =0; i < 4;i++){
      imm[8 + i] = binStr[20 + i]; 
   }
   imm[12] = '\0';
   immVal = binaryToDecimalSigned(imm, 12);
   if(strcmp(funct3, "000")==0){
      printf("beq x%d, x%d, PC + %d \n", regSrc1, regSrc2,  immVal);
   }
   else if(strcmp(funct3, "001")==0){
      printf("bne x%d, x%d, PC + %d \n", regSrc1, regSrc2,  immVal);
   }
   else if(strcmp(funct3, "100")==0){
      printf("blt x%d, x%d, PC + %d \n", regSrc1, regSrc2,  immVal);
   }      
    else if(strcmp(funct3, "101")==0){
      printf("bge x%d, x%d, PC + %d \n", regSrc1, regSrc2,  immVal);
   }   
   else if(strcmp(funct3, "110")==0){
      printf("bltu x%d, x%d, PC + %d \n", regSrc1, regSrc2,  immVal);
   }     
   else if(strcmp(funct3, "111")==0){
      printf("bgeu x%d, x%d, PC + %d \n", regSrc1, regSrc2,  immVal);
   }   
}

/* J Type below*/

void JType(char * binStr, char * line){
   int regDes;
   char  imm[6];
   char rd[6];
   for(int i = 0; i < 5;i++ ){
      rd[i] = binStr[20+i];
   }
   rd[5] ='\0';
   regDes = binaryToDecimalUnsigned(rd, 5);
   
   for(int i = 0; i < 5;i++){
      imm[i] = line[i];
   }
   imm[5] = '\0';
   printf("jal x%d, 0x%s\n", regDes, imm);
}

/* UType below */

void UType1(char * binStr, char * line){
   int regDes;
   char  imm[6];
   char rd[6];
   for(int i = 0; i < 5;i++ ){
      rd[i] = binStr[20+i];
   }
   rd[5] ='\0';
   regDes = binaryToDecimalUnsigned(rd, 5);
   
   for(int i = 0; i < 5;i++){
      imm[i] = line[i];
   }
   imm[5] = '\0';
   printf("lui x%d, 0x%s\n", regDes, imm);
}
/*UType2 below*/
void UType2(char * binStr, char * line){
   int regDes;
   char  imm[6];
   char rd[6];
   for(int i = 0; i < 5;i++ ){
      rd[i] = binStr[20+i];
   }
   rd[5] ='\0';
   regDes = binaryToDecimalUnsigned(rd, 5);
   
   for(int i = 0; i < 5;i++){
      imm[i] = line[i];
   }
   imm[5] = '\0';
   printf("auipc x%d, 0x%s\n", regDes, imm);
}

/*I type 2 below*/
void IType2(char * binStr){
   char funct3[4];
   //char funct6[7];
   int regDes;
   int regSrc1;
   int immVal;
   char rd[6];
   char rs1[6];
   char imm[13];
   for(int i = 0; i < 12;i++){
      imm[i] = binStr[i];
   }
   imm[12] ='\0';
   immVal = binaryToDecimalSigned(imm, 13);
   
   
   for(int i = 0; i < 5;i++ ){
      rs1[i] = binStr[12+i];
   }
   rs1[5]='\0';
   regSrc1 = binaryToDecimalUnsigned(rs1, 5);
      
   for(int i = 0; i < 5;i++ ){
      rd[i] = binStr[20+i];
   }
   rd[5] ='\0';
   regDes = binaryToDecimalUnsigned(rd, 5);
   
   /*for(int i = 0;i < 6;i++){
      funct6[i] = binStr[5 - i];
   }
   funct6[6]='\0';*/

   for(int i = 0; i < 3;i++){
      funct3[i] = binStr[17 + i];
   }
   funct3[3]='\0';
   
   if(strcmp(funct3, "000")==0){
      printf("lb x%d, %d (x%d)\n", regDes, immVal, regSrc1);
   }
   if(strcmp(funct3, "001")==0){
      printf("lh x%d, %d (x%d)\n", regDes, immVal, regSrc1);
   }   
   if(strcmp(funct3, "010")==0){
      printf("lw x%d, %d (x%d)\n", regDes, immVal, regSrc1);
   }
   if(strcmp(funct3, "011")==0){
      printf("ld x%d, %d (x%d)\n", regDes, immVal, regSrc1);
   }
   if(strcmp(funct3, "100")==0){
      printf("lbu x%d, %d (x%d)\n", regDes, immVal, regSrc1);
   }
   if(strcmp(funct3, "101")==0){
      printf("lhu x%d, %d (x%d)\n", regDes, immVal, regSrc1);
   }
   if(strcmp(funct3, "110")==0){
      printf("lwu x%d, %d (x%d)\n", regDes, immVal, regSrc1);
   }
}
/* IType 1  below*/
void IType1(char * binStr){
   char funct3[4];
   char funct6[7];
   int regDes;
   int regSrc1;
   int immVal;
   char rd[6];
   char rs1[6];
   char imm[13];
   for(int i = 0; i < 12;i++){
      imm[i] = binStr[i];
   }
   imm[12] ='\0';
   immVal = binaryToDecimalSigned(imm, 12);
   
   
   for(int i = 0; i < 5;i++ ){
      rs1[i] = binStr[12+i];
   }
   rs1[5]='\0';
   regSrc1 = binaryToDecimalUnsigned(rs1, 5);
      
   for(int i = 0; i < 5;i++ ){
      rd[i] = binStr[20+i];
   }
   rd[5] ='\0';
   regDes = binaryToDecimalUnsigned(rd, 5);
   
   for(int i = 0;i < 6;i++){
      funct6[i] = binStr[5 - i];
   }
   funct6[6]='\0';

   for(int i = 0; i < 3;i++){
      funct3[i] = binStr[17 + i];
   }
   funct3[3]='\0';
   
   if(strcmp(funct3, "001")==0 && strcmp(funct6, "000000")==0){
      printf("slli x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }
   if(strcmp(funct3, "101")==0 && strcmp(funct6, "000000")==0){
      printf("srli x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }
   if(strcmp(funct3, "101")==0 && strcmp(funct6, "010000")==0){
      printf("slli x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }   
      
   if(strcmp(funct3, "000")==0){
      printf("addi x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }   
   if(strcmp(funct3, "100")==0){
      printf("xori x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }  
   if(strcmp(funct3, "110")==0){
      printf("ori x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }     
   if(strcmp(funct3, "111")==0){
      printf("andi x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }   
   if(strcmp(funct3, "010")==0){
      printf("slti x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }   
   if(strcmp(funct3, "011")==0){
      printf("sltiu x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }   
}

void IType3(char * binStr){
   char funct3[4];
   //char funct6[7];
   int regDes;
   int regSrc1;
   int immVal;
   char rd[6];
   char rs1[6];
   char imm[13];
   for(int i = 0; i < 12;i++){
      imm[i] = binStr[i];
   }
   imm[12] ='\0';
   immVal = binaryToDecimalSigned(imm, 13);
   
   
   for(int i = 0; i < 5;i++ ){
      rs1[i] = binStr[12+i];
   }
   rs1[5]='\0';
   regSrc1 = binaryToDecimalUnsigned(rs1, 5);
      
   for(int i = 0; i < 5;i++ ){
      rd[i] = binStr[20+i];
   }
   rd[5] ='\0';
   regDes = binaryToDecimalUnsigned(rd, 5);
   
   /*for(int i = 0;i < 6;i++){
      funct6[i] = binStr[5 - i];
   }
   funct6[6]='\0';*/

   for(int i = 0; i < 3;i++){
      funct3[i] = binStr[17 + i];
   }
   funct3[3]='\0';
   
   if(strcmp(funct3, "000")==0 ){
      printf("jalr x%d, x%d, %d\n", regDes, regSrc1,immVal);
   }
   
}

char *binaryConversion(char hex) {
    char *hexReturn = (char *)malloc(5 * sizeof(char));
    switch (hex) {
        case '0':
            strcpy(hexReturn, "0000");
            break;
        case '1':
            strcpy(hexReturn, "0001");
            break;
        case '2':
            strcpy(hexReturn, "0010");
            break;
        case '3':
            strcpy(hexReturn, "0011");
            break;
        case '4':
            strcpy(hexReturn, "0100");
            break;
        case '5':
            strcpy(hexReturn, "0101");
            break;
        case '6':
            strcpy(hexReturn, "0110");
            break;
        case '7':
            strcpy(hexReturn, "0111");
            break;
        case '8':
            strcpy(hexReturn, "1000");
            break;
        case '9':
            strcpy(hexReturn, "1001");
            break;
        case 'A':
            strcpy(hexReturn, "1010");
            break;
        case 'B':
            strcpy(hexReturn, "1011");
            break;
        case 'C':
            strcpy(hexReturn, "1100");
            break;
        case 'D':
            strcpy(hexReturn, "1101");
            break;
        case 'E':
            strcpy(hexReturn, "1110");
            break;
        case 'F':
            strcpy(hexReturn, "1111");
            break;
        default:
            free(hexReturn);
            hexReturn = NULL;
    }
    
    return hexReturn;
}

void joinString(char *binaryStr1, char *bitString1, int v) {
    int i = v;
    int j = 0;
    while (j < 4) {
        binaryStr1[i] = bitString1[j];
        i++;
        j++;
    }
}

char *hexToBinary(char *readline) {
    int v = 0;
    char *binaryStr = (char *)malloc(33 * sizeof(char));
    binaryStr[32] = '\0';
    char *bitString;
    
    for (int i = 0; i < 8; i++) {
        bitString = binaryConversion(readline[i]);
        if (bitString == NULL) {
            
            break;
        }
        joinString(binaryStr, bitString, v);
        v += 4;
        free(bitString);
    }
    
    return binaryStr;
}
void opCodeCheck(char * binStr, char * line){
   char opCode[8];
   //strncpy(opCode, binStr[25], 7);
   for(int i = 0; i < 7; i++){
      opCode[i] = binStr[25+i];
   }
   opCode[7] = '\0';
   //printf("%s\n", opCode);
   //testCode
   /*if(strcmp(opCode,"0110010") == 0){
      printf("success\n");
   }*/
   /*if(strcmp(opCode, "")==0){
      printf("Type\n");
   }*/
   if(strcmp(opCode, "0110011")==0){
      //printf("Type R\n");
      RType(binStr);
   }
   else if(strcmp(opCode, "0010011") == 0){
      IType1(binStr);
   }
   
   else if(strcmp(opCode, "0000011")==0){
      IType2(binStr);
   }
   
   else if(strcmp(opCode,"1100111") == 0){
      IType3(binStr);
   }
   else if(strcmp(opCode,"0100011")==0){
      SType(binStr);
   }
   else if(strcmp(opCode, "1100011") == 0){
      BType(binStr);
   }
   else if(strcmp(opCode, "0110111")==0){
      UType1(binStr, line);
   }
   else if(strcmp(opCode, "0010111")==0){
      UType2(binStr, line);
   }
   else if(strcmp(opCode, "1101111")==0){
      JType(binStr, line);
   }
}

int main() {
    FILE *file = fopen("hex.txt", "r");

    
    //char *line = (char *)malloc(256 * sizeof(char));
    char line[1024];
    char *binaryString = (char *)malloc(1024 * sizeof(char));
    int opCode;
    
    binaryString[1023] = '\0';

    while (fgets(line, sizeof(line), file) != NULL) {
        binaryString = hexToBinary(line);
        //printf("%s\n", binaryString);
        //printf("%c", line[7]);
	opCodeCheck(binaryString, line);

    }

    //free(line);
    free(binaryString);
    fclose(file);

    return 0;
}

