
README FILE :

1. To compile the program:
	use command: gcc main.c -lm
	(program uses math.h library)
2.For imput:
	make sure that all the alphabets in hexadecimals should be in capital letters.
	for eg.
		address should be 5A2B34EF not 5a2b34EF.
			
